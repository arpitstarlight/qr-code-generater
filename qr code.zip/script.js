document.getElementById('generateBtn').addEventListener('click', function() {
    const text = document.getElementById('text').value.trim(); // Trim the input text
    const qrcodeContainer = document.getElementById('qrcode');
    const saveBtn = document.getElementById('saveBtn');

    // Clear previous QR Code
    qrcodeContainer.innerHTML = '';

    if (text) {
        // Generate QR Code
        const qrcode = new QRCode(qrcodeContainer, {
            text: text,
            width: 200,
            height: 200,
            colorDark: "#000000",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.H,
        });

        // Show save button after generating the QR code
        saveBtn.style.display = 'inline-block';

        // Add QR Code to canvas for downloading
        setTimeout(() => {
            const canvas = qrcodeContainer.querySelector('canvas');
            if (canvas) {
                // Update the download link to the QR code canvas data
                saveBtn.href = canvas.toDataURL('image/png');
                saveBtn.download = 'qrcode.png'; // Set the default name for the file
            }
        }, 100);
    } else {
        alert('Please enter a valid URL or text!'); // Alert for empty input
    }
});
